import { createContext } from "react";

let Demo = createContext;

export default Demo